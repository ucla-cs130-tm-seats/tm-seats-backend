
/*
 * similar(a,b)
 * returns double representing similarity between two profiles.
 * a,b: n-dimensional vectors (js associative list)
 */
var similar = function(a,b) {
   return 1.0;
}; 
