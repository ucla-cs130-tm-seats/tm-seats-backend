var http = require("http");
var fs = require('fs');
var url = require('url');
var qs = require('querystring');
var connect = require('connect');
var mongoose = require('mongoose');
var unirest = require('unirest');

mongoose.connect('mongodb://localhost/mydb');

var userSchema = mongoose.Schema({
    name: String,
    id: String,
    gender: String,
    dim1: String,
    dim2: String,
    dim3: String,
    dim4: String,
    dim5: String,
    dim6: String,
    dim7: String,
    dim8: String,
    dim9: String,
    dim10: String
});

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function callback() {
});

var User = mongoose.model('User', userSchema);
/*
var silence = new User({ name: 'Test User', id: '0000000000', gender: 'M',
                        dim1: 0, dim2: 0, dim3: 0, dim4: 0, dim5: 0, dim6: 0,
                        dim7: 0, dim8: 0, dim9: 0, dim10: 0 });
console.log(silence.name);

/* How to save a User to the database
silence.save(function (err, silence) {
    if (err) return console.error(err);
});
*/

http.createServer(function(request, response) {
    var parsedURL = url.parse(request.url, true);
    var path = parsedURL.pathname;
    var query = parsedURL.query;

    console.log(path);
    
    var pp = path.split('/');
    if (pp.length == 1)
        pp[1] = '';
    
    console.log(pp[1]);
    
    switch (pp[1])
    {
        case 'index.html':
            fs.readFile('index.html', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading index.html');
                }
                response.writeHead(200, {'Content-Type': 'text/html'});
                response.end(data);
            });
            break;
        case 'apicalls.js':
            fs.readFile('apicalls.js', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading apicalls.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;
        case 'facebook.js':
            fs.readFile('facebook.js', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading facebook.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;
        case 'transform.js':
            fs.readFile('transform.js', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading transform.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;  
        case 'd3.v3.min.js':
            fs.readFile('d3.v3.min.js', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading transform.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;  
            
        case 'bootstrap.min.css':
            fs.readFile('bootstrap.min.css', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading transform.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;  
            
        case 'similar.js':
            fs.readFile('similar.js', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading transform.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;  
        
        case 'process_vectors.js':
            fs.readFile('process_vectors.js', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading transform.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;  
            
        case 'kmeans.js':
            fs.readFile('kmeans.js', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading transform.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;  
            
        case 'graph.js':
            fs.readFile('graph.js', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading transform.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;  
            
        case 'style.css':
            fs.readFile('style.css', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading transform.js');
                }
                response.writeHead(200);
                response.end(data);
            });
            break;  
            
        case 'music':
            makeMusicRequest(pp[2], response);
            break;
        
        case 'data':
            makeDataRequest(pp, request, response);
            break;
        default:
            fs.readFile('index.html', function(err, data) {
                if (err) {
                    response.writeHead(500);
                    return response.end('Error loading index.html');
                }
                response.writeHead(200, {'Content-Type': 'text/html'});
                response.end(data);
            });
            break;
    }
}).listen(9000);

/*
connect.createServer(
    connect.static('C:/Users/Alexander Yang/Desktop/ServerStuff')
).listen(9000);
*/

function makeDataRequest(command, request, response) {
    console.log(command);
    if (command[2] == 'insert') {
        console.log('calling on');
        
        var body = '';
        request.setEncoding('utf8');
        request.on('data', function(data) {
            console.log(body);
            body += data;
        });
        request.on('end', function () {
            var data = JSON.parse(body);
            insert(data['user[]'], response);
        });
    }
    if (command[2] == 'find') {
        find(command[3], response);
    }
    if (!isNaN(parseInt(command[2]))) {
        select(parseInt(command[2]), response);
    }
}

function makeMusicRequest(title, response) {
    console.log(title);
    var Request = unirest.get("https://musixmatchcom-musixmatch.p.mashape.com/wsr/1.1/artist.search?q_artist=" 
                              + title + "&s_artist_rating=desc&page=1&page_size=1")
        .headers({ 
            "X-Mashape-Authorization": "2cr1N8ohrFjzuCx6CARpStyqk3CMDbG8"
        })
        .end(function (res) {
            console.log(res.body);
        response.writeHead(200);
        response.end(res.body);
  });
}

function insert(data, response) {
    User.find({ id: data[1] }, function(err, results) {
        console.log('Request to Insert. # of ID Found: ' + results.length);
        if (results.length == 0)
        {
            var silence = new User({ name: data[0], id: data[1], gender: data[2],
                            dim1: data[3], dim2: data[4], dim3: data[5], dim4: data[6], dim5: data[7], dim6: data[8],
                            dim7: data[9], dim8: data[10], dim9: data[11], dim10: data[12] });
            
            silence.save(function (err, silence) {
                if (err) return console.error(err);
            });
            
            response.writeHead(200);
            response.end();
        }
        else {
            response.writeHead(400);
            response.end();
        }
    });
}

function find(ide, response) {
    User.find({ id: parseInt(ide) }, function(err, results) {
        console.log('Request to find');
        console.log(results);
        response.writeHead(200);
        response.end(JSON.stringify(results[0]));
    });
}

function select(count, response) {
    console.log('select');
    User.find({}, function(err, results) {
        console.log('Request for select: # ' + count);
        console.log(results);
        var data = new Array();
        var max = results.length;
        var i = 0, j = 0;
        while (i < max && count > 0) {
            data[i] = results[j];
            count--;
            i++;
            j++;
        }
        console.log(JSON.stringify(data));
        response.writeHead(200);
        response.end(JSON.stringify(data));
    });
}