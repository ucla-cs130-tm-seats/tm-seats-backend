
var dummy_vectors = [
  [0.0,0,0.1],
  [0.0,0.1,0],
  [0.0,1.0,0],
  [0.1,0,0]
];

for(var i = 0; i < 80; i++) {
  dummy_vectors.push([Math.random(), Math.random(), Math.random()])
}

var distance = function(a, b) {
  ret = 0;
  jQuery.each(a, function(i) {
    ret = ret + Math.pow((a[i] - b[i]), 2);
  });
  return Math.sqrt(ret);
};

var process_vectors = function(vecs) {
  var matrix = [];
  
  jQuery.each(vecs, function(i, ival) {
    row = [];
    jQuery.each(vecs, function(j, jval) {
      row.push(distance(vecs[i], vecs[j]));
    });
    matrix.push(row);
  });
//  console.log(matrix);
  return matrix;
};

// process_vectors(dummy_vectors);