var build_graph = function(clusters, centroids) {
  console.log("building graph");
  console.log(clusters)
  var width = 1100,
    height = 600;
  
  var color = d3.scale.category20(); 
  
  /*var svg = d3.select("body").append("svg")
      .attr("width", width)
      .attr("height", height);*/
  var svg = d3.select("body")
    .append("svg")
    //.attr("preserveAspactRatio", "xMidYMid meet")
    //.attr("pointer-events", "all")
    .append('svg:g')
      .call(d3.behavior.zoom().on("zoom", redraw))
    .append('svg:g');

  svg.append('svg:rect')
    .attr('width', width)
    .attr('height', height)
    .attr('fill', 'white');

  function redraw() {
    svg.attr("transform",
      "translate(" + d3.event.translate + ")"
      + " scale(" + d3.event.scale + ")");
  }

  var graph = {
    nodes:[],
    links:[]
  };
  
  jQuery.each(clusters, function(cluster_index, cluster) {
    var vectors = cluster.cluster;
    cluster.node_indices = [];
    jQuery.each(vectors, function(i, vec_i) {
      cluster.node_indices[vec_i] =
          graph.nodes.push({name:vec_i.toString(), group:cluster_index, type:"subnode"}) - 1;
    });
  });
  jQuery.each(clusters, function(cluster_index, cluster) {
    var vectors = cluster.cluster;
    var centroid = cluster.centroid;
    
    jQuery.each(vectors, function(i, vec_i) {
      // add link to other vectors in cluster
      jQuery.each(vectors, function(j, vec_j) {
        if(cluster.matrix[i][j] < 0.22){
          graph.links.push({
              source: cluster.node_indices[vec_i],
              target: cluster.node_indices[vec_j],
              value: 800*cluster.matrix[i][j],
              type: "sublink"
          });
        }
      });
    });
  });
  centroids.centroid_indices = [];
  jQuery.each(centroids.centroids, function(centroid_index, centroid) {
    centroids.centroid_indices[centroid] =
          graph.nodes.push({name:centroid.toString(), group:-1, type:"supernode"}) - 1;
    // find cluster associated with centroid
    var clust = clusters[centroid_index].cluster;
    jQuery.each(clust, function(clust_index, vector) {
      graph.links.push({
          source: clusters[centroid_index].node_indices[vector],
          target: centroids.centroid_indices[centroid],
          value: 600*distance(vector, centroid),
          type: "superlink"
      });
      console.log(centroids.centroid_indices[centroid_index]);
    });
  });
  jQuery.each(centroids.centroids, function(centroid_index_i, centroid_i) {
    jQuery.each(centroids.centroids, function(centroid_index_j, centroid_j) {
      if(distance(centroid_i, centroid_j) < 0.01){
      graph.links.push({
          source: centroids.centroid_indices[centroid_i],
          target: centroids.centroid_indices[centroid_j],
          value: 120*distance(centroid_i, centroid_j),
          type: "superlink"
      });
      }
    });
  });
  
  var force = d3.layout.force()
      .charge(function(node) {return node.type == "supernode" ? 0 : -115;})
      .linkDistance(30)
      .gravity(0.02)
      .size([width, height])
      .nodes(graph.nodes)
      .links(graph.links)
      .linkDistance(function (l) {return l.value;})
      .linkStrength(function (l) {return l.type == "superlink" ? 0.05 : 1.0;})
      .start();

  var link = svg.selectAll(".link")
    .data(graph.links)
    .enter().append("line")
    .attr("class", "link")
    .style("display", function (l) {return l.type == "superlink" ? "none" : "";});

  var node = svg.selectAll(".node")
    .data(graph.nodes)
    .enter().append("circle")
    .attr("class", "node")
    .attr("r", 15)
    .style("fill", function(d) { return color(d.group); })
    .on("mouseover", function(){ 
      //d3.select(this).attr("r", 17);
    })
    .on("mouseout", function(){ 
      //d3.select(this).attr("r", 15);
    })
    .style("display", function (l) {return l.type == "supernode" ? "none" : "";})
    //.call(force.drag);

  node.append("title")
    .text(function(d) { return d.name; });

  svg.style("opacity", 1e-6)
    .transition()
      .duration(2000)
      .style("opacity", 1);

  force.on("tick", function() {
    link.attr("x1", function(d) { return d.source.x; })
      .attr("y1", function(d) { return d.source.y; })
      .attr("x2", function(d) { return d.target.x; })
      .attr("y2", function(d) { return d.target.y; });

    node.attr("cx", function(d) { return d.x; })
      .attr("cy", function(d) { return d.y; });
  });
};

